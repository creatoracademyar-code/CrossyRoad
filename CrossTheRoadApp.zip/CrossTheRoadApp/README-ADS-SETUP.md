# Real ads in Cross the Road — already wired up

Your real AdMob IDs are already plugged into this project:
- **App ID:** `ca-app-pub-6758883482672554~1275508476`
- **Interstitial ad unit ID:** `ca-app-pub-6758883482672554/1387189117`

Ads show as a full-screen interstitial after the player dies, but only
every 3–5 deaths (randomized), not every single one. Nothing else needs
to change in the code — from here it's just building, testing, and
publishing.

## What's in the project
- `app/src/main/assets/index.html` — the game calls
  `window.AndroidAds.showInterstitial()` every 3–5 deaths.
- `MainActivity.java` — loads the AdMob SDK, shows your real interstitial,
  and resumes the game once it's closed. Your `AD_UNIT_ID` is set here.
- `AndroidManifest.xml` — internet permission + your App ID are set here.
- `app/build.gradle` — AdMob library dependency added.

## ⚠️ Before you test: avoid accidental policy strikes
These are your **real, live** ad IDs now — every ad shown counts as a real
impression to advertisers. Do NOT repeatedly play/die/tap your own ads
over and over while testing; Google's invalid-traffic detection can
suspend your AdMob account for this, even unintentionally. To test safely:
- Play through a handful of times normally, don't loop deaths to farm ads.
- Or, temporarily add your device as a **test device** in the AdMob
  console (Settings → find your device's GAID, or check Logcat for
  "Use RequestConfiguration.Builder... to get test ads" the first time you
  run the app) so ads show as test ads on your phone only, while remaining
  real for everyone else.

## Step 1 — Build it
1. Open the `CrossTheRoadApp` folder in Android Studio.
2. Let Gradle sync (downloads the AdMob library the first time — needs
   internet, just once).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)** for a quick test
   install, or use the included GitHub Actions workflow.

## Step 2 — Test on your device
Install the APK, play a few rounds, die 3–5 times, and confirm a
full-screen ad appears before the game-over screen. If you set up a test
device (see warning above), it'll be clearly labeled as a test ad.

## Step 3 — EU/UK consent (Google Play requires this)
If your app can be downloaded in the EEA/UK, Play policy requires asking
for ad consent before showing ads there. The **User Messaging Platform
(UMP) SDK** ships as part of `play-services-ads` (already a dependency
here) — add a consent check at the top of `onCreate()` before
`loadInterstitialAd()` runs. Full guide:
https://developers.google.com/admob/android/privacy

## Step 4 — Publish for real
1. In Android Studio: **Build → Generate Signed Bundle / APK** → **Android
   App Bundle** → create/use your signing key → build **release**.
   Keep the keystore file + password safe forever — you need the exact
   same one for every future update.
2. Create a Play Console developer account (one-time $25) at
   https://play.google.com/console, make a new app listing, link it to
   your AdMob app, and upload the `.aab`.
3. Google reviews ad-serving apps before ads fully activate — allow a day
   or two after your first submission.

## Changing the ad frequency
In `app/src/main/assets/index.html`, inside the `Game` class, look at
`_randomAdThreshold()`:
```js
_randomAdThreshold() {
  return 3 + Math.floor(Math.random() * 3); // 3, 4, or 5
}
```
The first `3` is the minimum deaths between ads; the `3` inside
`Math.random() * 3` is the width of the range. For "every 4–6 deaths",
use `4 + Math.floor(Math.random() * 3)`.
