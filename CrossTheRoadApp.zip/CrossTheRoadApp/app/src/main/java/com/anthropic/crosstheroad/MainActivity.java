package com.anthropic.crosstheroad;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private InterstitialAd interstitialAd;

    // Your real interstitial ad unit ID from the AdMob console.
    private static final String AD_UNIT_ID = "ca-app-pub-6758883482672554/1387189117";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep the screen on while playing and go edge-to-edge.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemBars();

        // Start up the Mobile Ads SDK and load the first interstitial so
        // one is ready by the time the player dies for the first time.
        MobileAds.initialize(this, initializationStatus -> { });
        loadInterstitialAd();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        // DOM storage (localStorage) is what the game already uses to save
        // the best score. Enabling it here means the save code in the game
        // works completely unchanged, and the score persists across app
        // restarts but is wiped automatically if the app is uninstalled -
        // exactly like normal Android app data.
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // Exposes window.AndroidAds.showInterstitial() to the game's JS.
        // The game calls this every 3-5 deaths - see _showInterstitialAd()
        // in index.html.
        webView.addJavascriptInterface(new AndroidAdsBridge(), "AndroidAds");

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void loadInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, AD_UNIT_ID, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(InterstitialAd ad) {
                interstitialAd = ad;
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                interstitialAd = null;
            }
        });
    }

    /**
     * JS-callable bridge object. The game's JS calls
     * window.AndroidAds.showInterstitial() when it's due for an ad.
     */
    private class AndroidAdsBridge {
        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd == null) {
                    // Nothing loaded yet (e.g. no network right that
                    // moment) - don't block the player, just resume the
                    // game and try to have one ready for next time.
                    notifyGameAdClosed();
                    loadInterstitialAd();
                    return;
                }

                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        interstitialAd = null;
                        notifyGameAdClosed();
                        loadInterstitialAd(); // preload the next one
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError error) {
                        interstitialAd = null;
                        notifyGameAdClosed();
                        loadInterstitialAd();
                    }
                });

                interstitialAd.show(MainActivity.this);
            });
        }
    }

    /** Tells the game's JS the real ad has closed, so it can resume. */
    private void notifyGameAdClosed() {
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.__onInterstitialClosed && window.__onInterstitialClosed();", null));
    }

    private void hideSystemBars() {
        View decorView = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public void onBackPressed() {
        // Let the WebView handle back navigation if it ever has history;
        // otherwise fall back to the default (exit) behavior.
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
